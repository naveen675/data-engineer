import pandas as pd
import io
from datetime import datetime
from google.cloud import storage, bigquery, logging
from config import project_id, dataset_id, table_id, bucket_id, file_name, sender_email, sender_password, receiver_email, subject, sm_server, port, json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from google.oauth2 import service_account


os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = json

log_name = f"{datetime.now().strftime('logfile_%H_%M_%d_%m_%Y.log')}"


storage_client = storage.Client.from_service_account_json(json)
bq_client = bigquery.Client.from_service_account_json(json)
client = logging.Client.from_service_account_json(json)
logger = client.logger(log_name)
logger.log_text("Log Entry")
credentials = service_account.Credentials.from_service_account_file(json)


def read_file_from_storage(bucket_name, file_name):

    logger.log_text(f"Reading file {file_name}")

    file_path = f'gs://{bucket_name}/{file_name}'
    storage_df = pd.read_excel(file_path)
    return storage_df


def read_data_from_bigquery(project_id, table_id, dataset):

    logger.log_text(f"Reading gbq table {table_id}")

    query = f"select * from {project_id}.{dataset}.{table_id}"

    gbq_df = pd.read_gbq(query, credentials=credentials)
    # print(gbq_df)

    return gbq_df


def load_data_gbq_table(storage_df, gbq_df, table_name, dataset_name):

    merged = storage_df._append(gbq_df, ignore_index=True)

    columns = merged.columns.tolist()
    schema = []

    for column in columns:

        col = {'name': f'{column}', 'type': 'STRING'}

        schema.append(col)

    merged.fillna('None')
    merged = merged.astype(str)

    merged.to_gbq(f'{dataset_name}.{table_name}', if_exists='replace',
                  table_schema=schema, credentials=credentials)


def send_email(sender_email, sender_password, receiver_email, subject, message):

    smtp_server = sm_server
    smtp_port = port

    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg["Subject"] = subject

    msg.attach(MIMEText(message, "plain"))

    try:

        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)

        server.send_message(msg)

        server.quit()
        print("Email notification sent successfully!")
    except Exception as e:
        print("An error occurred while sending the email:", str(e))


def process_start(project_id, bucket_id, file_name, table_id, dataset_id):

    message = f"Hello, {file_name} has received into bucket Job is starting"
    send_email(sender_email, sender_password, receiver_email, subject, message)

    store_df = read_file_from_storage(bucket_id, file_name)

    bq_df = read_data_from_bigquery(project_id, table_id, dataset_id)

    load_data_gbq_table(store_df, bq_df, table_id, dataset_id)

    Output_folder = 'Output'
    cmd = f"gsutil mv 'gs://{bucket_id}/{file_name}' 'gs://{bucket_id}/{Output_folder}/'"
    os.system(cmd)
    logger.log_text(f'{cmd} Execution completed')


# def read_csv_from_storage(bucket_name, file_name):

#     bucket = storage_client.get_bucket(bucket_name)
#     blob = bucket.blob(file_name)
#     data = blob.download_as_text(raw_download=True)
#     print(f"Csv file reading completed")
#     return data


# def compare_columns(csv_data, dataset_id, table_id):

#     print(f"Compare columns with gbq table {dataset_id}.{table_id}")
#     dataset_ref = bq_client.dataset(dataset_id)
#     table_ref = dataset_ref.table(table_id)
#     table = bq_client.get_table(table_ref)
#     bq_columns = [field.name for field in table.schema]
#     print(csv_data)
#     csv_df = pd.read_csv(io.StringIO(csv_data))
#     csv_columns = csv_df.columns.tolist()
#     print(csv_columns)
#     new_columns = list(set(csv_columns) - set(bq_columns))
#     return csv_columns, new_columns


# def update_table_schema(dataset_id, table_id, new_columns):

#     dataset_ref = bq_client.dataset(dataset_id)
#     table_ref = dataset_ref.table(table_id)
#     table = bq_client.get_table(table_ref)
#     schema = table.schema
#     print(f"New Columns {new_columns}")
#     for column in new_columns:
#         schema.append(bigquery.SchemaField(column, "STRING"))
#     table.schema = schema
#     bq_client.update_table(table, ["schema"])


# def insert_data_to_table(dataset_id, table_id, csv_df):

#     print(f"Inserting data to gbq table")
#     dataset_ref = bq_client.dataset(dataset_id)
#     table_ref = dataset_ref.table(table_id)
#     job_config = bigquery.LoadJobConfig()
#     job_config.source_format = bigquery.SourceFormat.CSV
#     job_config.schema = [bigquery.SchemaField(
#         name, "STRING") for name in csv_df]
#     job_config.skip_leading_rows = 1  # Skip the header row in the CSV file
#     # Overwrite the table if it exists
#     job_config.write_disposition = bigquery.WriteDisposition.WRITE_APPEND

#     uri = f"gs://{bucket_id}/{file_name}"
#     load_job = bq_client.load_table_from_uri(
#         uri, table_ref, job_config=job_config)
#     load_job.result()  # Wait for the job to complete

#     if load_job.errors:
#         for error in load_job.errors:
#             print(f"Error loading file {file_name}: {error['message']}")
#     else:
#         print(f"File {file_name} loaded successfully to BigQuery.")

#     print("Data Load Completed")


# def process_csv_to_bq(bucket_name, file_name, dataset_id, table_id):

#     message = f"Hello, {file_name} has received into bucket Job is starting"

#     send_email(sender_email, sender_password, receiver_email, subject, message)

#     print(f"Reading {file_name} from Storage")
#     csv_data = read_csv_from_storage(bucket_name, file_name)
#     csv_columns, new_columns = compare_columns(
#         csv_data, dataset_id, table_id)
#     if new_columns:
#         update_table_schema(dataset_id, table_id, new_columns)

#     insert_data_to_table(dataset_id, table_id,
#                          csv_columns)

#     Output_folder = 'Output'

#     cmd = f'gsutil mv gs://{bucket_name}/{file_name} gs://{bucket_name}/{Output_folder}/'
#     os.run(cmd)
#     print(f'{cmd} Execution completed')
#     message = "File Processing Has been Completed"

#     send_email(sender_email, sender_password, receiver_email, subject, message)
